/*
Classe que representa um modelo de Cargo
*/
module.exports = class Cargo {
    //o pool de conexões e recebido no momento que é feito um: new Cargo(banco)
    //o new Cargo(banco) é realizado em todas as funções que que tratam as rotas GET,POST,PUT e DELETE.
    //as funções que tram as rotas estão localizadas no arquivo rotas_cargos.js
    //o pool de conexoes vira um atributo na classe Cargo
    //também é criado o atribudo idCargo e nomeCargo
    constructor(banco) {
        /*
        os atributos da classe para serem definidos com privados devem ser precedidos de _
        essa é apenas uma convensão pois o javascript não implemente de fato o conceito de:
         mediador de acesso privado, publico e protegido
        */
        //this._banco recebe o pool de conexoes que vem sendo passado desde o arqquivo app.js
        this._banco = banco;
        this._idCargo = null;
        this._nomeCargo = null;
    }

    /**
     * o método é chamado no arquivo rotas_cargos quando é recebido um POST:/cargos
     * @returns {Promise} resolve se cadastrado e reject caso aconteça algum erro
     */
    async create() {
        //cria uma promise que retornará dados referentes a execução de 
        //uma instrução sql no banco.
        const operacaoAssincrona = new Promise((resolve, reject) => {
            //recuperar o nomme cargo que foi passado no arquivo rotas_cargos.js
            //esse nome é passado na para a instância cargo na função que trata a rota POST:/cargos
            const nomeCargo = this.nomeCargo;

            //parametros é um vetor que recebe todos os dados que serão substituidos por ?
            //como só a um ? só existe uma posicição no vetor parametros
            //essa posição armazena o nome do cargo que será substituido pelo ?

            const parametros = [nomeCargo];
            const sql = "INSERT INTO cargo (nomeCargo) VALUES (?);";
            //depois da substituição a instrução sql é executada pelo método query
            //depois da substituição dos ? pelos dados a instrução sql é executada pelo método query
            //a substituição dos ? também é realizada no método _banco.query(
            this._banco.query(sql, parametros, function (error, result) {
                //caso aconteça algum erro a promise retorna um reject com o erro que ocorreu
                if (error) {
                    //caso aconteça algum erro a promise retorna um reject com o erro que ocorreu
                    //console envida dados no terminal, muito utilizado para debug
                    console.log("reject => Cargo.create(): " + JSON.stringify(error))
                    reject(error);
                } else {
                    //caso não aconteça nenhum erro a promise retorna um resolve.
                    //result é um consjuto de dados que contem informações 
                    //sobre a insersão do novo registro no banco de dados.
                    //console envida dados no terminal, muito utilizado para debug
                    console.log("resolve => Cargo.create(): " + JSON.stringify(result))
                    resolve(result);
                }
            });
        });
        //retorna uma promise para rotas_cargo
        return operacaoAssincrona;
    }



    //o método é chamado no arquivo rotas_cargos
    //quando é recebido um GET:/cargos ou
    //quando é recebido um GET:/cargos/:id
    //observe que as as duas rotas chamam o mesmo método read()

    async read() {
        //cria uma promise que retornará dados referentes a execução de 
        //uma instrução sql no banco.
        const operacaoAssincrona = new Promise((resolve, reject) => {
            //observe que o idCargo pode ou não ter sido inserido
            //se veio da GET: /cargos  => não foi inserido id, portanto é nulo
            //se veio da GET: /cargos/:id  => foi inserido id, id é equivalente ao valor que veio na uri

            const id = this.idCargo;

            //o id é passado como nulo ou como o id que veio na uri.
            const parametros = [id];

            let sql = "";

            //caso o id seja nulo entra no if e executa a primeira instrução sql
            //caso o id não seja nulo cai no else.
            if (id == null) {
                sql = "SELECT * FROM cargo order by nomeCargo";
            } else {
                sql = "SELECT * FROM cargo where idCargo=?";
            }

            //os parametros são substituidos pelos ? se houver
            this.banco.query(sql, parametros, function (error, result) {

                //caso aconteça algum erro a promise retorna um reject com o erro que ocorreu
                if (error) {
                    console.log("error => Cargo.read(): " + JSON.stringify(error))
                    reject(error);
                } else {
                    //caso não aconteça nenhum erro a promise retorna um resolve.
                    //result é um consjuto de dados que contem 
                    //as tuplas da execução da instrução sql 
                    //console envida dados no terminal, muito utilizado para debug
                    console.log("resolve => Cargo.read(): " + JSON.stringify(result))
                    resolve(result);
                }
            });
        });
        //retorna a promise.
        return operacaoAssincrona;
    }



    //o método update() é chamado no arquivo rotas_cargos
    //quando é recebido um PUT:/cargos/:id
    async update() {

        //cria uma promise que retornará dados referentes a execução de 
        //uma instrução sql no banco.
        const operacaoAssincrona = new Promise((resolve, reject) => {

            //recupera o id que foi inserido no atribudo idCargo
            //a inserção é feita no arquivo rotas_cargos.js
            //A inserção é feita dentro da função que trata a rota PUT:/cargos/:id
            const id = this.idCargo;

            //recupera o nome que foi inserido no atribudo nomeCargo
            //a inserção do nome é feita no arquivo rotas_cargos.js
            //A inserção é feita dentro da função que trata a rota PUT:/cargos/:id
            const nomeCargo = this.nomeCargo;

            //cria o vetor com os parametros que serão substitudios pelos sinais de ?
            const parametros = [nomeCargo, id];

            //cria a instrução sql que será executada
            const sql = "update cargo set nomeCargo=? where idCargo = ?";

            //substitui os sinais de ? pelos parametros e executa a instrução no sgbd
            this.banco.query(sql, parametros, function (error, result) {
                //caso aconteça algum erro a promise retorna um reject com o erro que ocorreu
                if (error) {
                    console.log("reject => Cargo.update(): " + JSON.stringify(error))
                    reject(error);
                } else {
                    //caso não aconteça nenhum erro a promise retorna um resolve.
                    //result é um consjuto de dados que contem informaçoes sobre a
                    //instrução sql que foi executada.
                    //console envida dados no terminal, muito utilizado para debug
                    console.log("resolve => Cargo.update(): " + JSON.stringify(result))
                    resolve(result);
                }
            });
        });
        
        //retorna uma promise para rotas_curso.js  na funçao => app.put('/cursos')
        return operacaoAssincrona;
    }


    //o método delete() é chamado no arquivo rotas_cargos.js
    //quando é recebido um DELETE:/cargos/:id
    async delete() {
        //cria uma promise que retornará dados referentes a execução de 
        //uma instrução sql no banco.
        const operacaoAssincrona = new Promise((resolve, reject) => {
            //recupera o id que foi inserido no atribudo idCargo
            //a inserção é feita no arquivo rotas_cargos.js
            //A inserção é feita dentro da função que trata a rota DELETE:/cargos/:id
            const idCargo = this.idCargo;
            //cria o vetor com os parametros que serão substitudios pelos sinais de ?
            let parametros = [idCargo];
            //cria a instrução sql que será executada
            let sql = "delete from cargo where idCargo=?";
            //substitui os sinais de ? pelos parametros e executa a instrução SQL no sgbd
            this.banco.query(sql, parametros, function (error, result) {
                if (error) {

                    // //console envida dados no terminal, muito utilizado para debug
                    console.log("reject => Cargo.delete(): " + JSON.stringify(error))
                    reject(error);
                } else {

                    //console envida dados no terminal, muito utilizado para debug
                    console.log("resolve => Cargo.delete(): " + JSON.stringify(result))

                    //caso não aconteça nenhum erro a promise retorna um resolve.
                    //result é um consjuto de dados que contem informaçoes sobre a
                    //instrução sql que foi executada.
                    resolve(result);
                }
            });
        });
        //retorna a promise
        return operacaoAssincrona;
    }



    //método não implementado para verificar se já existe um cargo com o mesmo nome
    async exists() {

    }

    /* instruções de get e set padrão */
    /* forma nova de fazer get/set usando js */

    set banco(banco) {
        this._banco = banco;
    }
    get banco() {
        return this._banco;
    }
    set idCargo(idCargo) {
        this._idCargo = idCargo;
    }
    get idCargo() {
        return this._idCargo;
    }
    set nomeCargo(nomeCargo) {
        this._nomeCargo = nomeCargo;
    }
    get nomeCargo() {
        return this._nomeCargo;
    }


}

