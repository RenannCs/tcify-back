module.exports = class Retangulo {
    base = null;
    altura =null;
    constructor(base,altura) {
        this.base = base;
        this.altura = altura;
    }
    calcularArea(){
        const area = this.base * this.altura;
        return area;
    }
    calcularPerimetro(){
        const perimetro = this.base*2 +  this.altura*2;
        return perimetro;
    }
    calcularDiagonal(){
        const diagonal = Math.sqrt(this.base*this.base + this.altura*this.altura);
        return diagonal;
    }
    setBase(base) {
        this.base = base;
    }
    getBase() {
        return this.base;
    }
    setAltura(altura) {
        this.altura = altura;
    }
    getAltura() {
        return this.altura;
    }
}

