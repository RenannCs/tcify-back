//
var md5 = require('md5'); //npm install md5 --save  doc=> https://www.npmjs.com/package/md5

module.exports = class Funcionario {

    constructor(banco) {
        /*
        os atributos da classe para serem definidos com privados devem ser precedidos de _
        essa é apenas uma convensão pois o javascript não implemente de fato o conceito de:
        mediador de acesso privado, publico e protegido
        */
        //this._banco recebe o pool de conexoes que vem sendo passado desde o arqquivo app.js
        this._banco = banco;
        this._idFuncionario = null;
        this._nome = null;
        this._email = null;
        this._senha = null;
        this._recebeValeTransporte = null;
        this._cargo = {
            idCargo: null,
            nomeCargo: null
        };
    }

    /**
     * o método é chamado no arquivo rotas_funcionarios.js quando é recebido um POST:/funcionário
     * @returns {Promise} resolve se cadastrado e reject caso aconteça algum erro
     */

    async create() {
        //cria uma promise que retornará dados referentes a execução de 
        //uma instrução sql no banco.
        const operacaoAssincrona = new Promise((resolve, reject) => {


            //recupera os dados do objeto funcionario
            //os dados foram passados para o objeto funcionario (this) no arquivo rotas_funcionarios.js
            //no método app.post('/funcionarios') 
            const nome = this.getNome();
            const email = this.getEmail();
            const senha = md5(this.getSenha());
            const recebeValeTransporte = this.getRecebeValeTransporte();

            const cargo = this.getCargo();

            const Cargo_idCargo = cargo.idCargo;

            //parametros é um vetor que recebe todos os dados que serão substituidos por ?
            const parametros = [nome, email, senha, recebeValeTransporte, Cargo_idCargo];

            // monta a instrução sql que será executada no sgbd
            let sql = "INSERT INTO funcionario (nome, email,senha, recebeValeTransporte, Cargo_idCargo) VALUES (?, ?, ?, ?, ?);";

            //depois da substituição dos ? pelos dados a instrução sql é executada pelo método query
            //a substituição dos ? também é realizada no método _banco.query(
            this._banco.query(sql, parametros, function (error, result) {
                if (error) {
                    //caso aconteça algum erro a promise retorna um reject com o erro que ocorreu
                    //console envida dados no terminal, muito utilizado para debug
                    console.log("reject => funcioario.create(): " + JSON.stringify(error))
                    reject(error);
                } else {
                    //caso não aconteça nenhum erro a promise retorna um resolve.
                    //result é um consjuto de dados que contem informações 
                    //sobre a insersão do novo registro no banco de dados.
                    //console envida dados no terminal, muito utilizado para debug
                    console.log("resolve => funcioario.create(): " + JSON.stringify(result))
                    resolve(result);
                }
            });
        });
        //retorna uma promise para rotas_funcionario
        return operacaoAssincrona;
    }


    /**
      * o método é chamado no arquivo rotas_funcionarios
      * quando é recebido um GET:/funcionarios ou
      * quando é recebido um GET:/funcionarios/:id
      * observe que as as duas rotas chamam o mesmo método read()
      * @returns {Promise} resolve se o sql for executado com sucesso e reject caso aconteça algum erro
      */
    async read() {
        //cria uma promise que retornará dados referentes a execução de 
        //uma instrução sql no banco.
        const operacaoAssincrona = new Promise((resolve, reject) => {
            //observe que o idFuncionario pode ou não ter sido inserido
            //se veio da GET:/funcionarios  => não foi inserido id, portanto é nulo
            //se veio da GET:/funcionarios/:id  => foi inserido id, id é equivalente ao valor que veio na uri

            const id = this.getIdFuncionario();

            //o id é passado como nulo ou como o id que veio na uri.
            let params = [id];

            let SQL = "";

            //caso o id seja nulo entra no if e executa a primeira instrução sql
            //caso o id não seja nulo cai no else
            if (id == null) {
                SQL = "SELECT idFuncionario,nome,email,recebeValeTransporte,idCargo,nomeCargo FROM funcionario JOIN cargo ON cargo.idCargo = funcionario.Cargo_idCargo  ORDER BY nome, nomeCargo";
            } else {
                SQL = "SELECT idFuncionario,nome,email,recebeValeTransporte,idCargo,nomeCargo FROM funcionario JOIN cargo ON cargo.idCargo = funcionario.Cargo_idCargo where idFuncionario=? ORDER BY nome, nomeCargo ";
            }

            //depois da substituição dos ? pelos dados a instrução sql é executada pelo método query
            //a substituição dos ? também é realizada no método _banco.query(
            this._banco.query(SQL, params, function (error, result) {
                if (error) {
                    //caso aconteça algum erro a promise retorna um reject com o erro que ocorreu
                    //console envida dados no terminal, muito utilizado para debug
                    console.log("reject => funcionario.create(): " + JSON.stringify(error))
                    reject(error);
                } else {
                    //caso não aconteça nenhum erro a promise retorna um resolve.
                    //result é um consjuto de dados que contem informações 
                    //sobre a insersão do novo registro no banco de dados.
                    //console envida dados no terminal, muito utilizado para debug
                    console.log("resolve => funcionario.create(): " + JSON.stringify(result))
                    resolve(result);
                }
            });
        });
        //retorna uma promise para rotas_funcionario.js  na funçao => app.get('/funcionarios')
        return operacaoAssincrona;
    }

    /**
      * o método é chamado no arquivo rotas_funcionarios pela função app.put('/funcionarios/:id')
      * quando é recebido um PUT:/funcionarios/:id
      * @returns {Promise} resolve se o sql for executado com sucesso e reject caso aconteça algum erro
      */
    async update() {

        //cria uma promise que retornará dados referentes a execução de 
        //uma instrução sql no banco.
        const operacaoAssincrona = new Promise((resolve, reject) => {


            const nome = this.getNome();
            const email = this.getEmail();
            const senha = md5(this.getSenha());
            const recebeValeTransporte = this.getRecebeValeTransporte();

            //recupera o id que foi inserido no atribudo idFuncionario
            //a inserção é feita no arquivo rotas_funcionario.js
            //A inserção é feita dentro da função que trata a rota PUT:/funcionarios/:id
            const idFuncionario = this.getIdFuncionario();

            const Cargo_idCargo = this.getCargo().idCargo;

            //cria o vetor com os parametros que serão substitudios pelos sinais de ?
            const parametros = [nome, email, senha, recebeValeTransporte, Cargo_idCargo, idFuncionario];

            //cria a instrução sql que será executada
            const sql = "update funcionario set nome=?,email=?,senha=?,recebeValeTransporte=?,Cargo_idCargo =? where idFuncionario = ?";

            //substitui os sinais de ? pelos parametros e executa a instrução no sgbd
            this._banco.query(sql, parametros, function (error, result) {
                //caso aconteça algum erro a promise retorna um reject com o erro que ocorreu
                if (error) {
                    console.log("reject => funcionario.update(): " + JSON.stringify(error))
                    reject(error);
                } else {

                    //caso não aconteça nenhum erro a promise retorna um resolve.
                    //result é um consjuto de dados que contem 
                    //as tuplas da execução da instrução sql 
                    //console envida dados no terminal, muito utilizado para debug
                    console.log("resolve => funcionario.update(): " + JSON.stringify(result))
                    resolve(result);
                }
            });
        });

        //retorna uma promise para rotas_funcionario.js  na funçao => app.put('/funcionarios')
        return operacaoAssincrona;
    }


    /**
      * o método é chamado no arquivo rotas_funcionarios pela função app.delete('/funcionarios/:id')
      * quando é recebido um DELETE:/funcionarios/:id
      * @returns {Promise} resolve se o sql for executado com sucesso e reject caso aconteça algum erro
    */
    async delete() {
        //cria uma promise que retornará dados referentes a execução de 
        //uma instrução sql no banco.
        const operacaoAssincrona = new Promise((resolve, reject) => {


            //recupera o id que foi inserido no atribudo idFuncionario
            //a inserção é feita no arquivo rotas_funcionario.js
            //A inserção é feita dentro da função que trata a rota DELETE:/funcionarios/:id
            const idFuncionario = this.getIdFuncionario();

            //cria o vetor com os parametros que serão substitudios pelos sinais de ?
            let parametros = [idFuncionario];

            //cria a instrução sql que será executada
            let sql = "delete from funcionario where idFuncionario = ?";
            //substitui os sinais de ? pelos parametros e executa a instrução no sgbd
            this._banco.query(sql, parametros, function (error, result) {
                if (error) {
                    //caso aconteça algum erro a promise retorna um reject com o erro que ocorreu
                    console.log("reject => funcionario.delete(): " + JSON.stringify(error));
                    reject(error);
                } else {
                    //caso não aconteça nenhum erro a promise retorna um resolve.
                    //result é um consjuto de dados que contem informaçoes sobre a
                    //instrução sql que foi executada.
                    //console envida dados no terminal, muito utilizado para debug
                    console.log("resolve => funcionario.delete(): " + JSON.stringify(result))
                    resolve(result);
                }
            });
        });
        return operacaoAssincrona;
    }


    async login() {
        const operacaoAssincrona = new Promise((resolve, reject) => {
            const email = this.getEmail();
            const senha = md5(this.getSenha());
            const parametros = [email, senha];


            const sql = "SELECT COUNT(*) AS qtd ,nome, email,idFuncionario,idCargo,nomeCargo FROM funcionario join cargo on idCargo= Cargo_idCargo WHERE email =? AND senha =?";

            this._banco.query(sql, parametros, (error, result) => {

                if (error) {
                    console.log(error)
                    reject(error);
                } else {
                    console.log(result)
                    if (result[0].qtd > 0) {
                        const resposta = {
                            status: true,
                            idFuncionario: result[0].idFuncionario,
                            nome: result[0].nome,
                            email: result[0].email,
                            idCargo: result[0].idCargo,
                            nomeCargo: result[0].nomeCargo,

                        }
                        resolve(resposta);
                    } else {
                        const resposta = {
                            status: false,
                        }
                        resolve(resposta);
                    }

                }
            });
        });
        return operacaoAssincrona;
    }



    // métodos get/set tradicionais


    setIdFuncionario(idFuncionario) {
        this._idFuncionario = idFuncionario
    }
    getIdFuncionario() {
        return this._idFuncionario
    }
    setNome(name) {
        this._nome = name;
    }
    getNome() {
        return this._nome;
    }
    setEmail(email) {
        this._email = email;
    }
    getEmail() {
        return this._email;
    }

    setSenha(senha) {
        this._senha = senha;
    }
    getSenha() {
        return this._senha;
    }
    setRecebeValeTransporte(recebeValeTransporte) {
        this._recebeValeTransporte = recebeValeTransporte;
    }
    getRecebeValeTransporte() {
        return this._recebeValeTransporte;
    }

    setCargo(cargo) {
        this._cargo = cargo;
    }
    getCargo() {
        return this._cargo;
    }


}

