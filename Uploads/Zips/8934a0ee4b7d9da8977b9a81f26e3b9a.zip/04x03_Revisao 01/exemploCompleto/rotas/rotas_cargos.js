/*
    Esse arquivo é responsavel por tratar todas as rotas de /cargos
*/


//Importa a classe Cargo
const Cargo = require("../modelo/Cargo");

//importa a classe JwtToken
//npm install jsonwebtoken --save 
//documentação: https://www.npmjs.com/package/jsonwebtoken
const JwtToken = require('../modelo/JwtToken');

//exporta o código abaixo como uma função.
//app e banco são passados como parametro em app.js
module.exports = function (app, banco) {

    //resposável por tratar POST: /cargos
    app.post('/cargos', (request, response) => {

        //imprime no console do terminal
        //útil para debug
        console.log("rota => POST: /cargos");

        //recupera o 'Bearer <' + TOKEN + '>' enviado pelo cliente
        const dadosAutorizacao = request.headers.authorization;
        //cria um objeto da classe JwtToken
        const jwt = new JwtToken();

        //verifica se o token enviado pelo cliente é válido
        const validarToken = jwt.validarToken(dadosAutorizacao);
        //entra no if se a validação do token é verdadeira
        //se a validação do token é verdadeira a propriedade validarToken.dados, 
        //possui dados do cliente no formato: {"email":"","nome":"","idFuncionario":"","idCargo":"","nomeCargo":""}
        //esses dados serão utilizados para gerar um novo token com a data de validade maior que a anterior.
        //toda vez que o token do cliente é validado é gerado um novo token mais novo na resposta da requisicao.
        if (validarToken.status == true) {
            //só executa se o token for válido
            //request.body é um objeto json que foi formado com texto json enviado no corpo da requisição
            //portanto foi enviado um json no formato: { "nomeCargo":"nome do cargo para cadastrar"}
            const nomeCargo = request.body.nomeCargo;

     
            //caso o nome seja vazio
            if (nomeCargo == "") {
                //cria um objeto json de resposta.
                const resposta = {
                    status: true,
                    msg: 'o nome não pode ser vazio',
                    codigo: '001',
                    dados: "{}",
                    token: jwt.gerarToken(validarToken.dados) //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
                }
                //envia a resposta para o cliente
                //http code = 200
                response.status(200).send(resposta);
            } else if (nomeCargo.length < 3) {
                //cria um objeto json de resposta.
                const resposta = {
                    status: true,
                    msg: 'o nome não pode ter menos do que 3 caracteres ',
                    codigo: '002',
                    dados: "{}",
                    token: jwt.gerarToken(validarToken.dados) //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
                }
                //envia a resposta para o cliente
                //http code = 200
                response.status(200).send(resposta);
            } else {
                //passando por todas as validações o código abaixo é executado.

                //é criado um o bjeto de cargo..
                //passa o objeto é passado o pool de conexoes com o banco
                const cargo = new Cargo(banco);

                //passa o objeto é passado o nome do cargo
                // chama o método  set nomeCargo(nomeCargo) na classe Cargo
                cargo.nomeCargo = nomeCargo;


                //chama o método create da classe cargo...
                //esse método executa uma instrução sql no banco.
                //then then()é executado se cargo.create() retorna um resolve do promise
                //caso contrário é executado um reject e cai no catch()
                cargo.create().then((resultadosBanco) => {
                    //só é executado em caso de sucesso no insert de um novo cargo.
                    //monta um json de resposta
                    const resposta = {
                        status: true,
                        msg: 'Executado com sucesso',
                        codigo: '003',
                        dados: {
                            idCargo: resultadosBanco.insertId,  // .insertId recupera o id do novo cargo criado
                            nomeCargo: cargo.nomeCargo    // chama o método  get nomeCargo() na classe Cargo
                        },
                        token: jwt.gerarToken(validarToken.dados) //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
                    }
                    //envia a respota para o cliente.
                    response.status(201).send(resposta);

                }).catch((erro) => {
                    //só é executado caso aconteça algum problema no insert de um novo cargo
                    //monta um objeto json de respota
                    const resposta = {
                        status: false,
                        msg: 'erro ao executar',
                        codigo: '004',
                        dados: erro,
                        token: jwt.gerarToken(validarToken.dados), //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
                    }
                    //envia resposta para o cliente
                    response.status(200).send(resposta);
                });;
            }
        } else {
            //token inválido
            //monta um objeto json para resposta
            const resposta = {
                status: false,
                msg: 'Usuário não logado',
                codigo: 401,
                dados: {},
                token: "" //como o token não foi valido, é enviado para o cliente um token vazio e ele perte a autorização de acesso ao sistema
            }
            //envia o objeto json como resposta para o cliente
            response.status(200).send(resposta);
        }
    });



    //resposável por tratar GET: /cargos
    app.get('/cargos', (request, response) => {
        console.log("rota: GET: /cargos");

        //recupera o 'Bearer <' + TOKEN + '>' enviado pelo cliente
        const dadosAutorizacao = request.headers.authorization;
        //cria um objeto da classe JwtToken
        const jwt = new JwtToken();

        //verifica se o token enviado pelo cliente é válido
        const validarToken = jwt.validarToken(dadosAutorizacao);
        //entra no if se a validação do token é verdadeira
        //se a validação do token é verdadeira a propriedade validarToken.dados, 
        //possui dados do cliente no formato: {"email":"","nome":"","idFuncionario":"","idCargo":"","nomeCargo":""}
        //esses dados serão utilizados para gerar um novo token com a data de validade maior que a anterior.
        //toda vez que o token do cliente é validado é gerado um novo token mais novo na resposta da requisicao.
        if (validarToken.status == true) {
            //console.log(validarToken.dados.data);
           // return;
            //passando pela validação do token o código abaixo é executado.

            //é criado um objeto de cargo..
            //para o objeto é passado o pool de conexoes com o banco
            const cargo = new Cargo(banco);

            //chama o método read() da classe Cargo...
            //esse método executa uma instrução sql no banco.
            //then then() é executado se cargo.read() retorna um resolve da promise
            //caso contrário é executado um reject e cai no catch()
            cargo.read().then((resultadosBanco) => {
                //monta um objeto json de resposta
                const resposta = {
                    status: true,
                    msg: 'Executado com sucesso',
                    codigo: '005',
                    dados: resultadosBanco,
                    token: jwt.gerarToken(validarToken.dados.data) //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
                }
                //envia a resposta para o cliente
                response.status(200).send(resposta);
            }).catch((erro) => {
                //só é executado caso aconteça algum problema no select dos cargos
                //monta um objeto json de respota
                const resposta = {
                    status: false,
                    msg: 'erro ao executar',
                    codigo: '006',
                    dados: erro,
                    token: jwt.gerarToken(validarToken.dados.data) //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
                }
                //envia uma respota para o cliente
                response.status(200).send(resposta);
            });;
        } else {
            //token inválido
            //monta um objeto json para resposta
            const resposta = {
                status: false,
                msg: 'Usuário não logado',
                codigo: 401,
                dados: {}
            }
            //envia o objeto json como resposta para o cliente
            response.status(200).send(resposta);

        }

    });

    //resposável por tratar GET: /cargos/:id
    app.get('/cargos/:id/', function (request, response) {
        console.log("GET: /cargos:id");
        //recupera o 'Bearer <' + TOKEN + '>' enviado pelo cliente
        const dadosAutorizacao = request.headers.authorization;
        //cria um objeto da classe JwtToken
        const jwt = new JwtToken();
        //verifica se o token enviado pelo cliente é válido
        const validarToken = jwt.validarToken(dadosAutorizacao);
        //entra no if se a validação do token é verdadeira
        //se a validação do token é verdadeira a propriedade validarToken.dados, 
        //possui dados do cliente no formato: {"email":"","nome":"","idFuncionario":"","idCargo":"","nomeCargo":""}
        //esses dados serão utilizados para gerar um novo token com a data de validade maior que a anterior.
        //toda vez que o token do cliente é validado é gerado um novo token mais novo na resposta da requisicao.
        if (validarToken.status == true) {

            //recupera o id que foi enviado na uri.
            //perceba que quando é enviado pelo uri é necessário
            //utilizar o  (request.params) e não o (request.body)
            const idCargo = request.params.id; // é params.id pq na rota foi definido (:id)

            //é criado um o bjeto de cargo..
            //para o objeto é passado o pool de conexoes com o banco
            const cargo = new Cargo(banco);

            //passa para o objeto cargo o id do cardo que deseja fazer o select
            // chama o método  set idcargo(id) na classe Cargo
            cargo.idCargo = idCargo;

            //chama o método read() da classe Cargo observe que o parametro idCargo não é passado
            //isso pq ele já está dentro do objeto Cargo e o método read() verifica se ele existe ou não internamente
            //esse método executa uma instrução sql no banco.
            //then then() é executado se cargo.read() retorna um resolve da promise
            //caso contrário é executado um reject e cai no catch()
            cargo.read().then((resultadosBanco) => {

                const resposta =
                {
                    status: true,
                    msg: 'Executado com sucesso',
                    codigo: '007',
                    dados: resultadosBanco,
                    token: jwt.gerarToken(validarToken.dados.data) //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
                }

                response.status(200).send(resposta);
            }).catch((erro) => {
                const resposta = {
                    status: false,
                    msg: 'erro ao executar',
                    codigo: '008',
                    dados: erro,
                    token: jwt.gerarToken(validarToken.dados.data) //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
                }
                response.status(200).send(resposta);
            });;
        } else {
            //token inválido
            //monta um objeto json para resposta
            const resposta = {
                status: false,
                msg: 'Usuário não logado',
                codigo: 401,
                dados: {},
                token: "" //como o token não foi valido, é enviado para o cliente um token vazio e ele perte a autorização de acesso ao sistema
            }
            //envia o objeto json como resposta para o cliente
            response.status(200).send(resposta);

        }
    });


    //resposável por tratar PUT: /cargos/:id
    app.put('/cargos/:id/', function (request, response) {
        console.log("rota: PUT: /cargos:id");

        //recupera o 'Bearer <' + TOKEN + '>' enviado pelo cliente
        const dadosAutorizacao = request.headers.authorization;
        //cria um objeto da classe JwtToken
        const jwt = new JwtToken();

        //verifica se o token enviado pelo cliente é válido
        const validarToken = jwt.validarToken(dadosAutorizacao);
        //entra no if se a validação do token é verdadeira
        //se a validação do token é verdadeira a propriedade validarToken.dados, 
        //possui dados do cliente no formato: {"email":"","nome":"","idFuncionario":"","idCargo":"","nomeCargo":""}
        //esses dados serão utilizados para gerar um novo token com a data de validade maior que a anterior.
        //toda vez que  o token do cliente é validado é gerado um novo token mais novo na resposta da requisicao.
        if (validarToken.status == true) {

            //recupera o id que foi enviado na uri.
            //perceba que quando é enviado pelo uri é necessário
            //utilizar o  (request.params) e não o (request.body)
            const idCargo = request.params.id; // é params.id pq na rota foi definido (:id)

            //só executa se o token for válido
            //request.body é um objeto json que foi formado com texto json enviado no corpo da requisição
            //portanto foi enviado um json no formato: { "nomeCargo":"nome do cargo para atualizar"}
            const nomeCargo = request.body.nomeCargo;


            //é criado um o bjeto de cargo..
            //para o objeto é passado o pool de conexoes com o banco
            const cargo = new Cargo(banco);

            //passa para o objeto cargo o id do cardo que deseja fazer a atualização
            cargo.idCargo = idCargo;
            //passa o objeto é passado o nome do cargo
            //// chama o método  set nomeCargo(nomeCargo) na classe Cargo
            cargo.nomeCargo = nomeCargo;


            //chama o método update() da classe Cargo observe que o parametro idCargo não é passado
            //isso pq ele já está dentro do objeto Cargo e o método update() verifica se ele existe ou não internamente
            //esse método executa uma instrução sql no banco.
            //then then() é executado se cargo.update() retorna um resolve da promise
            //caso contrário é executado um reject e cai no catch()
            cargo.update().then((resultadosBanco) => {
                //prepara uma resposta que será enviada como json para o cliente
                const resposta = {
                    status: true,
                    msg: 'Executado com sucesso',
                    codigo: '009',
                    dados: {
                        id: cargo.idCargo,
                        nomeCargo: cargo.nomeCargo
                    },
                    token: jwt.gerarToken(validarToken.dados.data) //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
                };
                //envia a resposta para o cliente
                response.status(200).send(resposta);
            }).catch((erro) => {
                const resposta = {
                    status: false,
                    msg: 'erro ao executar',
                    codigo: '010',
                    dados: erro,
                    token: jwt.gerarToken(validarToken.dados.data), //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
                }
                response.status(200).send(resposta);
            });;
        } else {
            //token inválido
            //monta um objeto json para resposta
            const resposta = {
                status: false,
                msg: 'Usuário não logado',
                codigo: 401,
                dados: {},
                token: "" //como o token não foi valido, é enviado para o cliente um token vazio e ele perte a autorização de acesso ao sistema
            }
            //envia o objeto json como resposta para o cliente
            response.status(200).send(resposta);

        }
    });


    /**
     *   resposável por tratar DELETE: /cargos/:id
     */
    app.delete('/cargos/:id/', function (request, response) {
        console.log("rota: DELETE: /cargos:id");

        //recupera o 'Bearer <' + TOKEN + '>' enviado pelo cliente
        const dadosAutorizacao = request.headers.authorization;
        //cria um objeto da classe JwtToken
        const jwt = new JwtToken();

        //verifica se o token enviado pelo cliente é válido
        const validarToken = jwt.validarToken(dadosAutorizacao);
        //entra no if se a validação do token é verdadeira
        //se a validação do token é verdadeira a propriedade validarToken.dados, 
        //possui dados do cliente no formato: {"email":"","nome":"","idFuncionario":"","idCargo":"","nomeCargo":""}
        //esses dados serão utilizados para gerar um novo token com a data de validade maior que a anterior.
        //toda vez que o token do cliente é validado é gerado um novo token mais novo na resposta da requisicao.
        if (validarToken.status == true) {


            //recupera o id que foi enviado na uri.
            //perceba que quando é enviado pelo uri é necessário
            //utilizar o  (request.params) e não o (request.body)
            const id = request.params.id; // é params.id pq na rota foi definido (:id)


            //é criado um o bjeto de cargo..
            //para o objeto é passado o pool de conexoes com o banco
            const cargo = new Cargo(banco);

            //passa para o objeto cargo o id do cargo que será exluido  
            // chama o método  set idCargo(nomeCargo) na classe Cargo
            cargo.idCargo = id;

            //chama o método delete() da classe Cargo observe que o parametro idCargo não é passado
            //isso pq ele já está dentro do objeto Cargo e o método read() verifica se ele existe ou não internamente
            //esse método (delete()) executa uma instrução sql no banco.
            //then then() é executado se cargo.delete() retorna um resolve da promise
            //caso contrário é executado um reject e cai no catch()
            cargo.delete().then((resultadosBanco) => {
                const resposta = {
                    status: true,
                    msg: 'Excluido com sucesso com sucesso',
                    codigo: '011',
                    dados: {
                        id: cargo.idCargo
                    },
                    token: jwt.gerarToken(validarToken.dados.data), //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
                };

                response.status(200).send(resposta);
            }).catch((erro) => {
                const resposta = {
                    status: false,
                    msg: 'erro ao executar',
                    codigo: '012',
                    dados: erro,
                    token: jwt.gerarToken(validarToken.dados.data), //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
                }
                response.status(200).send(resposta);
            });
        } else {
            //token inválido
            //monta um objeto json para resposta
            const resposta = {
                status: false,
                msg: 'Usuário não logado',
                codigo: 401,
                dados: {},
                token: "" //como o token não foi valido, é enviado para o cliente um token vazio e ele perte a autorização de acesso ao sistema
            }
            //envia o objeto json como resposta para o cliente
            response.status(200).send(resposta);

        }
    });

};