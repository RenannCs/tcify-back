
//app e banco são recebidos quando fazemos a chamada
// de rotas_funcionarios no arquivo app.js
module.exports = function (app, banco) {

  const Funcionario = require("../modelo/Funcionario");

  //importa a classe JwtToken
  //npm install jsonwebtoken --save 
  //documentação: https://www.npmjs.com/package/jsonwebtoken
  const JwtToken = require('../modelo/JwtToken');

  //importa a classe Cargo.js
  const Cargo = require('../modelo/Cargo');

  //resposável por tratar POST: /login
  app.post('/login', (request, response) => {
    console.log("rota: POST: /login");

    //recupera o 'Bearer <' + TOKEN + '>' enviado pelo cliente
    const dadosAutorizacao = request.headers.authorization;

    //cria um objeto da classe JwtToken



    const email = request.body.email;
    const senha = request.body.senha;

    //faça as validações para verificar se os dados são válidos e consistentes antes de continuar.

    if (email == "" || senha == "") {
      //cria um objeto json de resposta.
      const resposta = {
        status: false,
        msg: 'email ou senha não podem ser vazios',
        codigo: '001',
        dados: "{}",
        token: jwt.gerarToken(validarToken.dados.data) //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
      }
      //envia a resposta para o cliente
      //http code = 200
      response.status(200).send(resposta);

    } else {
      //só execute o método .login() se os dados recebidos do cliente forem validados
      const funcionario = new Funcionario(banco)

      //insere os dados de email e senha dentro da instancia de funcionario
      funcionario.setEmail(email);
      funcionario.setSenha(senha);

      //chama o método da classe funcionário que é responsavel por validar o login
      //then then() é executado se funcionario.login() retorna um resolve da promise
      //caso contrário é retornado um reject e é executado o catch()
      //note que não há passagem de parametro para login, ja que os dados foram inseridos no objeto em:
      // funcionario.setEmail(email); e funcionario.setSenha(senha)
      funcionario.login().then((respostaLogin) => {

        //entra no if caso o email e senha sejam validados no método funcionario.login()
        if (respostaLogin.status == true) {

          //monta um objeto com dados do usuário que serão utilizados para montar o token
          //todos esses dados são gerado no método funcionario.login() caso sejam fornecidos
          //email e senha corretos
          const usuario = {
            email: respostaLogin.email,
            nome: respostaLogin.nome,
            idFuncionario: respostaLogin.idFuncionario,
            idCargo: respostaLogin.idCargo,
            nomeCargo: respostaLogin.nomeCargo,
          }

          //cria um objeto de JwtToken
          const jwt = new JwtToken();
          //gera um novo token com base no objeto Json usuario construido acima
          const novoToken = jwt.gerarToken(usuario);

          //é construido um objeto de resposta
          const resposta = {
            status: true,
            msg: "Login efetuado com sucesso",
            token: novoToken,
            funcionario: usuario
          }
          //a resposta é enviada para o cliente da api
          response.status(201).send(resposta);
        } else {
          //caso não sejam fornecidos email e senha corretos cai no else
          //é constuira uma resposta para o usuario sem o token
          //o usuário é informado que não foi logado.
          //é enviado um token vazio
          const resposta = {
            status: false,
            msg: "Usuário não logado",
            codigo: 401,
            token: "",
          }
          //envia o objeto resposta como resposta para o usuário
          response.status(200).send(resposta);
        }

      }).catch((erro) => {
        //caso aconteça algum erro na execução da tarefa no banco de dado
        // o código catch é executado
        const resposta = {
          status: false,
          msg: 'erro ao executar',
          codigo: '005',
          dados: erro,
        }
        //envia o objeto respota como resposta para o cliente da api
        response.status(201).send(erro);
      });

    }
  });



  /*************************************************************************************************************************** */
  //create
  app.post('/funcionarios', (request, response) => {

    //imprime no console do terminal
    //útil para debug
    console.log("rota => POST: /funcionarios");

    //recupera o 'Bearer <' + TOKEN + '>' enviado pelo cliente
    const dadosAutorizacao = request.headers.authorization;

    //cria um objeto da classe JwtToken
    const jwt = new JwtToken();

    //verifica se o token enviado pelo cliente é válido
    const validarToken = jwt.validarToken(dadosAutorizacao);

    //entra no if se a validação do token é verdadeira
    //se a validação do token é verdadeira a propriedade validarToken.dados, 
    //possui dados do cliente no formato: {"email":"","nome":"","idFuncionario":"","idCargo":"","nomeCargo":""}
    //esses dados serão utilizados para gerar um novo token com a data de validade maior que a anterior.
    //toda vez que o token do cliente é validado é gerado um novo token mais novo na resposta da requisicao.
    if (validarToken.status == true) {

      const nome = request.body.nome;
      const email = request.body.email;
      const senha = request.body.senha;
      const recebeValeTransporte = request.body.vt;
      const idCargo = request.body.idCargo;

      //antes de cadastrar um novo funcionário valide todos os dados de entrada:
      //caso o nome seja vazio
      if (nome == "") {
        //cria um objeto json de resposta.
        const resposta = {
          status: true,
          msg: 'o nome não pode ser vazio',
          codigo: '001',
          dados: "{}",
          token: jwt.gerarToken(validarToken.dados.data) //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
        }
        //envia a resposta para o cliente
        //http code = 200
        response.status(200).send(resposta);
      } else if (email == "") {
        //trate o email inválido
      } else {
        //o else só deve ser executado se todas as validações forem feitas
        const funcionario = new Funcionario(banco);

        funcionario.setNome(nome);
        funcionario.setEmail(email);
        funcionario.setSenha(senha);
        funcionario.setRecebeValeTransporte(recebeValeTransporte);

        const cargo = new Cargo();

        cargo.idCargo = idCargo;

        //outro modo de get e set, modo mais antigo...
        funcionario.setCargo(cargo);

        //chama o método create da classe Funcionario...
        //esse método executa uma instrução sql no banco.
        //then then() é executado se funcionario.create() retorna um resolve do promise
        //caso contrário é executado um reject e cai no catch()
        funcionario.create().then((resultadosBanco) => {
          //monta um objeto json de resposta com os dados do novo funcionário cadastrado
          const resposta = {
            status: true,
            msg: 'Executado com sucesso',
            codigo: '002',
            dados: {
              idFuncionario: resultadosBanco.insertId,
              nome: funcionario.getNome(),
              email: funcionario.getEmail(),
              recebeValeTransporte: funcionario.getRecebeValeTransporte(),
              idCargo: funcionario.getCargo().idCargo
            },
            token: jwt.gerarToken(validarToken.dados.data) //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
          }
          response.status(200).send(resposta);
        }).catch((erro) => {
          console.error('Error retrieving users:', erro);
        });;
      }
    } else {
      //token inválido
      //monta um objeto json para resposta
      const resposta = {
        status: false,
        msg: 'Usuário não logado',
        codigo: 401,
        dados: {},
        token: "" //como o token não foi valido, é enviado para o cliente um token vazio e ele perte a autorização de acesso ao sistema
      }
      //envia o objeto json como resposta para o cliente
      response.status(200).send(resposta);
    }
  });


  /**
   *  
   * resposável por tratar GET: /funcionarios 
   * 
   */

  app.get('/funcionarios', function (request, response) {
    console.log("rota: GET: /funcionarios");

    //recupera o 'Bearer <' + TOKEN + '>' enviado pelo cliente
    const dadosAutorizacao = request.headers.authorization;
    //cria um objeto da classe JwtToken
    const jwt = new JwtToken();

    //verifica se o token enviado pelo cliente é válido
    const validarToken = jwt.validarToken(dadosAutorizacao);

    //entra no if se a validação do token é verdadeira
    //se a validação do token é verdadeira a propriedade validarToken.dados, 
    //possui dados do cliente no formato: {"email":"","nome":"","idFuncionario":"","idCargo":"","nomeCargo":""}
    //esses dados serão utilizados para gerar um novo token com a data de validade maior que a anterior.
    //toda vez que o token do cliente é validado é gerado um novo token mais novo na resposta da requisicao.
    if (validarToken.status == true) {
      //passando pela validação do token o código abaixo é executado.

      //é criado um objeto de funcionario..
      //para o objeto é passado o pool de conexoes com o banco
      const funcionario = new Funcionario(banco);


      //chama o método read() da classe Funcionario...
      //esse método executa uma instrução sql no banco.
      //then then() é executado se funcionario.read() retorna um resolve da promise
      //caso contrário é executado um reject e cai no catch()
      funcionario.read().then((resultadosBanco) => {

        const resposta = {
          status: true,
          msg: 'Executado com sucesso',
          dados: resultadosBanco,
          codigo: '003',
          token: jwt.gerarToken(validarToken.dados.data) //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
        };
        //envia a resposta para o cliente
        response.status(200).send(resposta);
      }).catch((erro) => {

        //só é executado caso aconteça algum problema no select dos funcionarios
        //monta um objeto json de respota
        const resposta = {
          status: false,
          codigo: '004',
          msg: 'erro ao executar',
          dados: erro
        };
        //envia uma respota para o cliente
        response.status(200).send(resposta);

      });;
    } else {
      //token inválido
      //monta um objeto json para resposta
      const resposta = {
        status: false,
        msg: 'Usuário não logado',
        codigo: 401,
        dados: {},
        token: "" //como o token não foi valido, é enviado para o cliente um token vazio e ele perte a autorização de acesso ao sistema
      }
      //envia o objeto json como resposta para o cliente
      response.status(200).send(resposta);
    }
  });

  /**
     * 
     *  resposável por tratar get:/funcionarios/:id
     * 
     */
  app.get('/funcionarios/:id/', (request, response) => {

    console.log("GET: /funcionarios:id");
    //recupera o 'Bearer <' + TOKEN + '>' enviado pelo cliente
    const dadosAutorizacao = request.headers.authorization;
    //cria um objeto da classe JwtToken
    const jwt = new JwtToken();
    //verifica se o token enviado pelo cliente é válido
    const validarToken = jwt.validarToken(dadosAutorizacao);
    //entra no if se a validação do token é verdadeira
    //se a validação do token é verdadeira a propriedade validarToken.dados, 
    //possui dados do cliente no formato: {"email":"","nome":"","idFuncionario":"","idCargo":"","nomeCargo":""}
    //esses dados serão utilizados para gerar um novo token com a data de validade maior que a anterior.
    //toda vez que o token do cliente é validado é gerado um novo token mais novo na resposta da requisicao.
    if (validarToken.status == true) {

      //recupera o id que foi enviado na uri.
      //perceba que quando é enviado pelo uri é necessário
      //utilizar o  (request.params) e não o (request.body)

      const idFuncionario = request.params.id;

      //é criado um o bjeto de funcionario..
      //para o objeto é passado o pool de conexoes com o banco
      const funcionario = new Funcionario(banco);

      funcionario.setIdFuncionario(idFuncionario);


      //chama o método read() da classe Funcionario...

      //esse método executa uma instrução sql no banco.
      //then then() é executado se funcionario.read() retorna um resolve da promise
      //caso contrário é executado um reject e cai no catch()
      //note que o ide não é passado como parametro na chamda do método read.
      //isso não é necessário pois o id ja foi passado para instancia anteriomrente em:
      //  funcionario.setIdFuncionario(idFuncionario);
      funcionario.read().then((resultadosBanco) => {
        const resposta = {
          status: true,
          msg: 'executado com sucesso',
          dados: resultadosBanco,
          token: jwt.gerarToken(validarToken.dados.data) //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
        };
        response.status(200).send(resposta);
      }).catch((erro) => {

        const resposta = {
          status: false,
          msg: 'erro ao executar',
          codigo: '005',
          dados: erro,

          token: jwt.gerarToken(validarToken.dados.data) //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
        }
        response.status(200).send(resposta);

      });;
    } else {
      //token inválido
      //monta um objeto json para resposta
      const resposta = {
        status: false,
        msg: 'Usuário não logado',
        codigo: 401,
        dados: {},
        token: "" //como o token não foi valido, é enviado para o cliente um token vazio e ele perte a autorização de acesso ao sistema
      }
      //envia o objeto json como resposta para o cliente
      response.status(200).send(resposta);

    }
  });


  /**
   * update
   */
  app.put('/funcionarios/:id', (request, response) => {
    console.log("rota: PUT: /funcionarios");

    //recupera o 'Bearer <' + TOKEN + '>' enviado pelo cliente
    const dadosAutorizacao = request.headers.authorization;
    //cria um objeto da classe JwtToken
    const jwt = new JwtToken();

    //verifica se o token enviado pelo cliente é válido
    const validarToken = jwt.validarToken(dadosAutorizacao);

    //entra no if se a validação do token é verdadeira
    //se a validação do token é verdadeira a propriedade validarToken.dados, 
    //possui dados do cliente no formato: {"email":"","nome":"","idFuncionario":"","idCargo":"","nomeCargo":""}
    //esses dados serão utilizados para gerar um novo token com a data de validade maior que a anterior.
    //toda vez que o token do cliente é validado é gerado um novo token mais novo na resposta da requisicao.
    if (validarToken.status == true) {
      const idFuncionario = request.params.id;

      const nome = request.body.nome;
      const email = request.body.email;
      const senha = request.body.senha;
      const recebeValeTransporte = request.body.vt;
      const idCargo = request.body.idCargo;

      //antes de cadastrar um novo funcionário valide todos os dados de entrada:
      //caso o nome seja vazio
      if (nome == "") {
        //cria um objeto json de resposta.
        const resposta = {
          status: true,
          msg: 'o nome não pode ser vazio',
          codigo: '006',
          dados: "{}",
          token: jwt.gerarToken(validarToken.dados.data) //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
        }
        //envia a resposta para o cliente
        //http code = 200
        response.status(200).send(resposta);
      } else if (email == "") {
        //trate o email inválido
      } else {
        const funcionario = new Funcionario(banco);

        funcionario.setIdFuncionario(idFuncionario);
        funcionario.setNome(nome);
        funcionario.setEmail(email);
        funcionario.setSenha(senha);
        funcionario.setRecebeValeTransporte(recebeValeTransporte);

        const cargo = new Cargo();

        //forma moderna de tragar get e set
        cargo.idCargo = idCargo;

        //outro modo de get e set, legado..
        funcionario.setCargo(cargo);

        //chama o método update() da classe Cargo, observe que o parametro idfuncionario não é passado
        //isso pq ele já está dentro do objeto Cargo e o método read() verifica se ele existe ou não internamente
        //esse método executa uma instrução sql no banco.
        //then then() é executado se funcionario.update() retorna um resolve da promise
        //caso contrário é executado um reject e cai no catch()

        funcionario.update().then((resultadosBanco) => {
          const resposta = {
            status: true,
            msg: 'Executado com sucesso',
            codigo: '007',
            dados: {
              idFuncionario: funcionario.getIdFuncionario(),
              nome: funcionario.getNome(),
              email: funcionario.getEmail(),
              recebeValeTransporte: funcionario.getRecebeValeTransporte(),
              idCargo: funcionario.getCargo().idCargo
            },
            token: jwt.gerarToken(validarToken.dados.data) //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
          }
          response.status(200).send(resposta);
        }).catch((erro) => {
          const resposta = {
            status: false,
            msg: 'erro ao executar',
            codigo: '010',
            dados: erro,
            token: jwt.gerarToken(validarToken.dados.data), //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
          }
          response.status(200).send(resposta);
        });;
      }
    } else {
      //token inválido
      //monta um objeto json para resposta
      const resposta = {
        status: false,
        msg: 'Usuário não logado',
        codigo: 401,
        dados: {},
        token: "" //como o token não foi valido, é enviado para o cliente um token vazio e ele perte a autorização de acesso ao sistema
      }
      //envia o objeto json como resposta para o cliente
      response.status(200).send(resposta);
    }
  });


  /**
   * resposável por tratar DELETE: /funcionarios/:id
   */
  app.delete('/funcionarios/:id', (request, response) => {

    console.log("rota: DELETE: /cargos:id");

    //recupera o 'Bearer <' + TOKEN + '>' enviado pelo cliente
    const dadosAutorizacao = request.headers.authorization;
    //cria um objeto da classe JwtToken
    const jwt = new JwtToken();

    //verifica se o token enviado pelo cliente é válido
    const validarToken = jwt.validarToken(dadosAutorizacao);
    //entra no if se a validação do token é verdadeira
    //se a validação do token é verdadeira a propriedade validarToken.dados, 
    //possui dados do cliente no formato: {"email":"","nome":"","idFuncionario":"","idCargo":"","nomeCargo":""}
    //esses dados serão utilizados para gerar um novo token com a data de validade maior que a anterior.
    //toda vez que o token do cliente é validado é gerado um novo token mais novo na resposta da requisicao.
    if (validarToken.status == true) {


      //recupera o id que foi enviado na uri.
      //perceba que quando é enviado pelo uri é necessário
      //utilizar o  (request.params) e não o (request.body)
      const id = request.params.id; // é params.id pq na rota foi definido (:id)

      const funcionario = new Funcionario(banco);
      funcionario.setIdFuncionario(id);

      funcionario.delete().then((resultadosBanco) => {
        const resposta = {
          status: true,
          msg: 'Excluido com sucesso',
          codigo: '008',
          dados: {
            idFuncionario: funcionario.getIdFuncionario(),
          },
          token: jwt.gerarToken(validarToken.dados.data), //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
        }
        response.status(200).send(resposta);
      }).catch((erro) => {
        const resposta = {
          status: false,
          msg: 'erro ao executar',
          codigo: '009',
          dados: erro,
          token: jwt.gerarToken(validarToken.dados.data), //como o token foi validado é gerado um novo token mais novo com os dados do cliente.
        }
        response.status(200).send(resposta);
      });
    } else {
      //token inválido
      //monta um objeto json para resposta
      const resposta = {
        status: false,
        msg: 'Usuário não logado',
        codigo: 401,
        dados: {},
        token: "" //como o token não foi valido, é enviado para o cliente um token vazio e ele perte a autorização de acesso ao sistema
      }
      //envia o objeto json como resposta para o cliente
      response.status(200).send(resposta);

    }
  });
};