

//recupera o token que foi gravado no local Storage no momento do login e armazena na variavel global TOKEN
const TOKEN = localStorage.getItem("token");

//determina a URI do serviço de cargos da api
const URI_CARGOS = "/cargos";

//quando os cargos forem carregados, serão armazenados nessa variável global
let CARGOS_JSON = {};

//recupera uma instância de cada elemento visual
const txtCargo = document.getElementById("txtCargo");
const txtIdCargo = document.getElementById("txtIdCargo");
const txtFiltro = document.getElementById("txtFiltro");
const tblCargos = document.getElementById("tblCargos");

const divResposta = document.getElementById("divResposta");

const btnCadastrar = document.getElementById("btnCadastrar");
const btnAtualizar = document.getElementById("btnAtualizar");
const btnExcluir = document.getElementById("btnExcluir");
const btnCancelar = document.getElementById("btnCancelar");

//vincula o evento aos componentes;
btnCadastrar.onclick = btnCadastrar_onclick;
btnAtualizar.onclick = btnAtualizar_onclick;
btnExcluir.onclick = btnExcluir_onclick;
btnCancelar.onclick = btnCancelar_onclick;

//vincula o evento de "levantar tecla" na caixa de texto de filtro
txtFiltro.onkeyup = txtFiltro_onkeyup;

//executa a função fetch_cargos_get()
window.onload = function () {
    /*
    *existeSessao(): essa função está dentro do arquivo sessao.js
    *portanto no html carregue o arquivo sessao.js antes do cargos.js
    */
    existeSessao();

    //função que faz uma requisição para api retornar todos os cargos.
    fetch_cargos_get();
}

/*
*Função que trata o evento de click do botão cadastrar
*/
function btnCadastrar_onclick() {

    //recupera o texto que foi digitado na caixa de texto
    const v_cargo = txtCargo.value;

    //verifica se o cargo não é inválido
    if (v_cargo == "") {
        divResposta.append(document.createTextNode("Cargo não pode ser vazio"));

    } else if (1 != 1) {
        //faça outras verificações  
    } else {
        //passadas por todas as verificações 
        //cria um objeto json cointendo dados do cargo que será cadastrado
        const objJsonCargo = {
            nomeCargo: v_cargo
        }
        //chama a função que fará um post para a restapi
        //que é responsável por cadastrar o cargo no banco de dados.
        fetch_cargo_create(objJsonCargo);
    }
}


/*
*Função que trata o evento de click do botão Atualizar
*/
function btnAtualizar_onclick() {
    const id = txtIdCargo.value
    const cargo = txtCargo.value;
    if (id == "") {
        limparDiv(divResposta);
        divResposta.append(document.createTextNode("Selecione um cargo"));
    } else {
        const objJson = {
            nomeCargo: cargo
        };

        fetch_cargos_put(id, objJson);
    }

}

/*
*Função que trata o evento de click do botão Excluir
*/
function btnExcluir_onclick() {
    const id = txtIdCargo.value;
    if (id == "") {
        limparDiv(divResposta);
        divResposta.append(document.createTextNode("Selecione um cargo"));
    } else {
        fetch_cargos_delete(id);
    }
}

/*
*Função que trata o evento de click do botão Cance4lar
*/
function btnCancelar_onclick() {
    limparFormulario();
}

/*
*Função que trata o evento de onkeyup da caixa de filtro
*/
function txtFiltro_onkeyup() {
    let filtro = txtFiltro.value;
    construirTabelaCargos(filtro);
}


/*
*Função que limpa todos os campos do formulário
*/
function limparFormulario() {
    txtIdCargo.value = "";
    txtCargo.value = "";
    limparDiv(divResposta);
}
/**
*Função que remove todos os componentes dentro de uma div
* @param {*} objetoDiv recebe como parametro uma instância de uma div.
*/
function limparDiv(objetoDiv) {
    while (objetoDiv.hasChildNodes() == true) {
        objetoDiv.removeChild(objetoDiv.firstChild);
    }
}

/**
*Função que remove todas as linhas da tabela
*não é removida a lihha zero, pois a mesma contem os títulos das colunas
* @param {*} objetoDiv recebe como parametro uma instância de uma tabela.
*/
function limparTabela(objetoTabela) {
    var qtdLinhas = 1;
    var totalLinhas = objetoTabela.rows.length;
    for (var i = qtdLinhas; i < totalLinhas; i++) {
        objetoTabela.deleteRow(qtdLinhas);
    }
}


/**
 * Constroi uma tabela com os cargos
 * @param {*} filtroNomeCargo  recebe um texto para contrurir a tabela somente com cargos que possuam o texto recebido
 */
function construirTabelaCargos(filtroNomeCargo) {
    //limpa a tabela antes de construir uma nova.
    limparTabela(tblCargos);

    //CARGOS_JSON é carregado na função fetch_cargos_get(), CARGOS_JSON é uma variável global
    //fetch_cargos_get() é chamado no evento de load do documento
    for (let cargo of CARGOS_JSON) {

        //se filtroNomeCargo for diferente de nulo os dados serão filtrados
        //de acordo com o valor de filtroNomeCargo
        if (filtroNomeCargo != null) {

            //converte o nome do cargo atual que está no array CARGOS_JSON para minusculo
            let nomeCargo = cargo.nomeCargo.toLowerCase();

            //converte o dado digitado na caixa de texto de filtro para minusculo
            filtroNomeCargo = filtroNomeCargo.toLowerCase();

            //verifica se o nomeCargo do cargo que veio do array possui 
            //o texto que está dentro de filtroNomeCargo
            if (nomeCargo.includes(filtroNomeCargo) == false) {
                //se não possui o nome cargo não precisa ser adicionado
                //então é pulado para o proximo cargo do array.
                continue;
                //depois do continue nada é executado e a estrutura de repetição passa para o proximo cargo
            }
        }
        //cria um novo elemento do tipo tr => linha de uma tabela
        const linha = document.createElement("tr");

        //cria um novo elemento do tipo td => coluna de uma tabela
        const colunaIdCargo = document.createElement("td");

        //cria um novo elemento do tipo td => coluna de uma tabela
        const colunaNomeCargo = document.createElement("td");

        //cria um novo elemento do tipo td => coluna de uma tabela
        const colunaBotaoSelecionar = document.createElement("td");

        //cria um novo elemento do tipo button => Botao dde comando
        //esse botão servirá para que o usuário possa selecionar um cargo
        //ao selecionar o usuário poderá escolher entre: atulizar, exluir ou cancelar operação
        const btnSelecionar = document.createElement("button");

        // vincula um texto sobre o botão
        btnSelecionar.append(document.createTextNode("Selecionar"));

        //vincula o evento de click sobre o botão.
        btnSelecionar.onclick = function () {
            //caso seja efetuado o evento de click sobre o botão criado
            //os componentes txtIdCargo e txtCargo terão seus textos
            //alterados conforme o cargo escolhido pelo usuário
            txtIdCargo.value = cargo.idCargo;
            txtCargo.value = cargo.nomeCargo;
        }

        //adiciona os textos correspondentes as colunas da tabela

        //adiciona o id do cargo na coluna colunaIdCargo
        colunaIdCargo.append(document.createTextNode(cargo.idCargo));

        //adiciona o nomeCargo do cargo na coluna colunaNomeCargo
        colunaNomeCargo.append(document.createTextNode(cargo.nomeCargo));

        // //adiciona o btnSelecionar do cargo na coluna colunaBotaoSelecionar
        colunaBotaoSelecionar.append(btnSelecionar);

        //adiciona as colunas as linhas
        linha.appendChild(colunaIdCargo);
        linha.appendChild(colunaNomeCargo);
        linha.appendChild(colunaBotaoSelecionar);

        //adiciona a linha a tabela
        tblCargos.appendChild(linha);

    }

}

function fetch_cargo_create(objJsonCargo) {
    //tranforma o objeto json recebido em texto json.
    const string_json = JSON.stringify(objJsonCargo);

    //fetch faz uma requisição assincrona
    //a requisição é do tipo POST
    //envia no corpo(body) da requisição o json com os dados que serão cadastrados
    //define os cabeçalhos(headers) da requisição
    //envia o token de autorização no cabeçalho  da requisição
    const operacao_assincrona = fetch(URI_CARGOS,
        {
            method: "POST",
            body: string_json,
            headers: {
                'Accept': 'application/json',               //Aceita json como resposta da api
                "Content-Type": "application/json",         //Informa que irá enviar para api conteúdo em json
                "Authorization": 'Bearer <' + TOKEN + '>',  //Envia o token de autorização para a api
            }
        });

    //caso seja retornada uma resposta da api, ela será processada abaixo
    operacao_assincrona.then((response) => { return response.text(); }).then((jsonResposta) => {
        //é execudado quando a api "js" responde.

        //mostra o contúdo recebido da api no console do navegador.
        console.log("RECEBIDO:", jsonResposta);

        //converte a resposta da api para um objeto json.
        const objetoJson = JSON.parse(jsonResposta);

        //caso o status da resposta seja true entra no if
        if (objetoJson.status == true) {

            //recupera o novo token e armanzena no localStorage
            localStorage.setItem("token", objetoJson.token);

            //limpa a div resposta
            limparDiv(divResposta);

            //mostra texto na div resposta
            divResposta.append(document.createTextNode("cadastrado com sucesso"));

            //limpra o formulário de cadastro
            limparFormulario();

            //carrega novamente todos os cargos para refazer a tabela.
            fetch_cargos_get();


        } else {
            let codigo = objetoJson.codigo;
            if (codigo == 401) {
                divResposta.append(document.createTextNode(objetoJson.msg));
                divResposta.append(document.createTextNode("usuário não logado"));
            } else if (codigo == 404) {
                //trate todos os códigos que a api pode retornar
            }
        }

    });

    //caso aconteça algum erro o catch é chamado e o erro é apresentado no console do navegador
    operacao_assincrona.catch((error) => {
        console.error("Error:", error);
    });
}


function fetch_cargos_get() {

    //fetch faz uma requisição assincrona
    //a requisição é do tipo GET
    //não enviada nada no corpo(body) da requisição
    //define os cabeçalhos(headers) da requisição
    //envia o token de autorização no cabeçalho  da requisição
    const operacao_assincrona = fetch(URI_CARGOS,
        {
            method: "GET",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                "Authorization": 'Bearer <' + TOKEN + '>',
            }
        });

    //caso seja retornada uma resposta da api, ela será processada abaixo
    operacao_assincrona.then((response) => { return response.text(); }).then((jsonResposta) => {
        //é execudado quando a api "js" responde.
        //mostra o contúdo recebido da api no console do navegador.
        console.log("RECEBIDO:", jsonResposta);

        //converte a resposta da api para um objeto json.
        const objetoJson = JSON.parse(jsonResposta);

        //caso o status da resposta seja true entra no if
        if (objetoJson.status == true) {

            //joga os dados contendo todos os cargos na variável global CARGOS_JSON
            //CARGOS_JSON é um array com todos os cargos retornados pela API
            CARGOS_JSON = objetoJson.dados;

            //recupera o novo token e armanzena no localStorage
            localStorage.setItem("token", objetoJson.token)

            //chama o função que irá constuir a tabela com todos os cargos
            construirTabelaCargos();
        } else {
            //caso o status da resposta não seja true
            //verifica o código de erro que foi retornado
            let codigo = objetoJson.codigo;
            if (codigo == 401) {
                divResposta.append(document.createTextNode("usuário não logado"));
            } else if (codigo == 404) {
                //trate todos os códigos que a api pode retornar
            }

        }

    });

    //caso aconteça algum erro o catch é chamado e o erro é apresentado no console do navegador
    operacao_assincrona.catch((error) => {
        console.error("Error:", error);
    });
}


function fetch_cargos_put(id, objJsonCargo) {



    //tranforma o objeto json recebido em texto json.
    const stringJson = JSON.stringify(objJsonCargo);

    //monta a uri para fazer o put
    const uri_put = URI_CARGOS + "/" + id;

    //fetch faz uma requisição assincrona
    //a requisição é do tipo PUT
    //é enviado no corpo(body) da requisição os dados que serão atualizados
    //define os cabeçalhos(headers) da requisição
    //envia o token de autorização no cabeçalho  da requisição
    const operacao_assincrona = fetch(uri_put, {
        method: "PUT",
        body: stringJson,
        headers: {
            'Accept': 'application/json',               //Aceita json como resposta da api
            'Content-Type': 'application/json',         //Informa que irá enviar para api conteúdo em json
            "Authorization": 'Bearer <' + TOKEN + '>',  //Envia o token de autorização para a api
        }
    })
    //caso seja retornada uma resposta da api, ela será processada abaixo

    operacao_assincrona.then((response) => { return response.text(); }).then((jsonResposta) => {
        //é execudado quando a api "js" responde.

        //mostra o contúdo recebido da api no console do navegador.
        console.log("RECEBIDO:", jsonResposta);

        //converte a resposta da api para um objeto json.
        const objetoJson = JSON.parse(jsonResposta);

        //caso o status da resposta seja true entra no if
        if (objetoJson.status == true) {

            //recupera o novo token e armanzena no localStorage
            localStorage.setItem("token", objetoJson.token);

            //limpra o formulário de cadastro
            limparFormulario();

            //limpra o formulário de cadastro
            limparDiv(divResposta);

            divResposta.append(document.createTextNode("atualizado com sucesso"));

            //carrega novamente todos os cargos para refazer a tabela.
            fetch_cargos_get();

        } else {
            let codigo = objetoJson.codigo;
            if (codigo == 401) {
                divResposta.append(document.createTextNode("usuário não logado"));
            }
        }

    })
    operacao_assincrona.catch((error) => {
        console.error("Error:", error);
    });
}


function fetch_cargos_delete(id) {


    //monta a uri para fazer o DELETE
    const uri_delete = URI_CARGOS + "/" + id;

    //fetch faz uma requisição assincrona
    //a requisição é do tipo DELETE
    //não é enviado no corpo(body) da requisição  dado algum
    //define os cabeçalhos(headers) da requisição
    //envia o token de autorização no cabeçalho  da requisição
    const operacao_assincrona = fetch(uri_delete, {
        method: "DELETE",
        headers: {
            'Accept': 'application/json',               //Aceita json como resposta da api
            'Content-Type': 'application/json',         //Informa que irá enviar para api conteúdo em json
            "Authorization": 'Bearer <' + TOKEN + '>',  //Envia o token de autorização para a api
        }
    });

    //caso seja retornada uma resposta da api, ela será processada abaixo
    operacao_assincrona.then((response) => { return response.text(); }).then((jsonResposta) => {
        //é execudado quando a api "js" responde.

        //mostra o contúdo recebido da api no console do navegador.
        console.log("RECEBIDO:", jsonResposta);

        //converte a resposta da api para um objeto json.
        const objetoJson = JSON.parse(jsonResposta);

        //caso o status da resposta seja true entra no if
        if (objetoJson.status == true) {

            //recupera o novo token e armanzena no localStorage
            localStorage.setItem("token", objetoJson.token)
            
            //limpra o formulário de cadastro
            limparFormulario();
            
            //limpa a div resposta
            limparDiv(divResposta);
            
            //escreve a mensagem que veio como resposta na da api na div
            divResposta.append(document.createTextNode("atualizado com sucesso"));

            //faz novamente a requisição de cargos para api
            fetch_cargos_get();
            
           
        } else {
            let codigo = objetoJson.codigo;
            if (codigo == 401) {
                divResposta.append(document.createTextNode("usuário não logado"));
            }else if (codigo == 404) {
                //trate todos os códigos que a api pode retornar
            }
        }
    });

    //caso aconteça algum erro o catch é chamado e o erro é apresentado no console do navegador
    operacao_assincrona.catch((error) => {
        console.error("Error:", error);
    });
}


