
/**
  * a função é chamada no carregamento de cada pagina html onde o scritp foi carregado
  * verifica se existe um token gerado e se existe dados do funcionario logado
  * caso não exista o usuário será redirecionado para a página de login
 */
function existeSessao() {
    /**
     * O localStorage é um recurso do JavaScript que permite 
     * que você armazene dados no navegador da web de forma persistente.
     * Esses dados são armazenados localmente no dispositivo do usuário(navegador)
     * e persistem mesmo após o fechamento do navegador.
     * O localStorage é útil para armazenar pequenas quantidades de informações, c
     * omo configurações de usuário, preferências ou até mesmo dados temporários, 
     * como um carrinho de compras em uma loja online
     */

    //tenta recuperar o valor da variavel (token) no localStorage
    let token = localStorage.getItem("token");

    //tenta recuperar o valor da variavel (jsonFuncionario) no localStorage
    let jsonFuncionario = localStorage.getItem("jsonFuncionario");

    //caso uma das variaveis não exista o usuário é direcionado para a página de login
    if (token == null || jsonFuncionario == null) {
        window.location = "Login.html"
    } else {
        //apresenta no console do navegador
        console.log(token, jsonFuncionario);
    }
}
//executa a função no carregamento do script
///existeSessao();